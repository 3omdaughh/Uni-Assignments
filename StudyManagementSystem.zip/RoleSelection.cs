﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudyManagementSystem
{
    public partial class RoleSelection : Form
    {
        public RoleSelection()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Login studentLogin = new Login(); 
            studentLogin.Show();
            this.Hide();
        }

        private void btnInstructor_Click(object sender, EventArgs e)
        {
            InstructorLogin form = new InstructorLogin();
            form.Show();
            this.Hide();
        }

        private void gradientPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void RoleSelection_Load(object sender, EventArgs e)
        {

        }

    }
}
