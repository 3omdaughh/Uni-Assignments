﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudyManagementSystem
{
    public partial class Registerition : Form
    {
        public Registerition()
        {
            InitializeComponent();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text == "" || txtEmail.Text == "")
            {
                MessageBox.Show("Please fill all fields");
            }
            else
            {
                RegistrationStep2 step2 = new RegistrationStep2();

                step2.username = txtUsername.Text;
                step2.email = txtEmail.Text;

                step2.Show();

                this.Hide();
            }
        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
