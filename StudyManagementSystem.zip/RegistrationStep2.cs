﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudyManagementSystem
{
    public partial class RegistrationStep2 : Form
    {

        public string username;
        public string email;
        public RegistrationStep2()
        {
            InitializeComponent();

            comboRole.Items.Add("Student");
            comboRole.Items.Add("Instructor");
        }

        private void RegistrationStep2_Load(object sender, EventArgs e)
        {

        }

        private void btnRegester_Click(object sender, EventArgs e)
        {
            if (txtPassword.Text == "" ||
       txtConfirmPassword.Text == "" ||
       comboRole.Text == "")
            {
                MessageBox.Show("Please fill all fields");
            }
            else if (txtPassword.Text != txtConfirmPassword.Text)
            {
                MessageBox.Show("Passwords do not match");
            }
            else
            {
                User newUser = new User();

                newUser.Username = username;
                newUser.Email = email;
                newUser.Password = txtPassword.Text;
                newUser.Role = comboRole.Text;

                UserData.Users.Add(newUser);

                MessageBox.Show("Registration Successful");

                if (comboRole.Text == "Student")
                {
                    Login login = new Login();
                    login.Show();
                }
                else
                {
                    InstructorLogin instructor = new InstructorLogin();
                    instructor.Show();
                }

                this.Hide();
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Registerition register = new Registerition();

            register.Show();

            this.Hide();
        }

        private void comboRole_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
