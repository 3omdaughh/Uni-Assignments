﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudyManagementSystem
{
    public partial class DashboardStudent : Form
    {
        int seconds = 0;
        public DashboardStudent()
        {
            InitializeComponent();
        }

        private void DashboardStudent_Load(object sender, EventArgs e)
        {

        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            Timer1.Start();
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            Timer1.Stop();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            seconds++;

            TimeSpan time = TimeSpan.FromSeconds(seconds);

            labelTimer.Text = time.ToString(@"hh\:mm\:ss");
        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            CoursesForm courses = new CoursesForm();

            courses.Show();

            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ScheduleForm schedule = new ScheduleForm();

            schedule.Show();

            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LeaderboardForm leaderboard = new LeaderboardForm();

            leaderboard.Show();

            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SettingsForm settings = new SettingsForm();

            settings.Show();

            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
       "Are you sure you want to logout?",
       "Logout",
       MessageBoxButtons.YesNo,
       MessageBoxIcon.Question
   );

            if (result == DialogResult.Yes)
            {
                RoleSelection role = new RoleSelection();

                role.Show();

                this.Hide();
            }
        }
    }
}
