﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudyManagementSystem
{
    public partial class CoursesForm : Form
    {
        public CoursesForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DashboardStudent dashboard = new DashboardStudent();

            dashboard.Show();

            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            ScheduleForm schedule = new ScheduleForm();

            schedule.Show();

            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LeaderboardForm leaderboard = new LeaderboardForm();

            leaderboard.Show();

            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SettingsForm settings = new SettingsForm();

            settings.Show();

            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
       "Are you sure you want to logout?",
       "Logout",
       MessageBoxButtons.YesNo,
       MessageBoxIcon.Question
   );

            if (result == DialogResult.Yes)
            {
                RoleSelection role = new RoleSelection();

                role.Show();

                this.Hide();
            }
        }
    }
}
