﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudyManagementSystem
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void panelleft_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void panelright_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        

        private void Password_TextChanged(object sender, EventArgs e)
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {
            string Username = txtUsername.Text;
            string password = txtPassword.Text;

            if (Username == "" || password == "")
            {
                MessageBox.Show("Please enter email and password");
                return;
            }

            if (Username == "menna" && password == "1234")
            {
                MessageBox.Show("Login Successful");

                DashboardStudent student = new DashboardStudent();

                student.Show();

                this.Hide();

                
            }
            else
            {
                MessageBox.Show("Invalid Email or Password");
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Registerition register = new Registerition();

            register.Show();

            this.Hide();
        }
    }
        
}