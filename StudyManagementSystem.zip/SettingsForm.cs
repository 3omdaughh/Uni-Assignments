﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudyManagementSystem
{
    public partial class SettingsForm : Form
    {
        public SettingsForm()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string language = comboLanguage.Text;

            string theme = comboTheme.Text;

            bool darkMode = checkDarkMode.Checked;

            bool notifications = checkNotifications.Checked;

            bool remember = checkRemember.Checked;

            MessageBox.Show(
                "Settings Saved Successfully!",
                "Settings",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
            );
        }

        private void button6_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
       "Are you sure you want to logout?",
       "Logout",
       MessageBoxButtons.YesNo,
       MessageBoxIcon.Question
   );

            if (result == DialogResult.Yes)
            {
                RoleSelection role = new RoleSelection();

                role.Show();

                this.Hide();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DashboardStudent dashboard = new DashboardStudent();

            dashboard.Show();

            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            CoursesForm courses = new CoursesForm();

            courses.Show();

            this.Hide();
        }

        private void btnSchedule_Click(object sender, EventArgs e)
        {
            ScheduleForm schedule = new ScheduleForm();

            schedule.Show();

            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LeaderboardForm leaderboard = new LeaderboardForm();

            leaderboard.Show();

            this.Hide();
        }
    }
}
