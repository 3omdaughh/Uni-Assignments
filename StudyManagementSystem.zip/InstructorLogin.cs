﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudyManagementSystem
{
    public partial class InstructorLogin : Form
    {
        public InstructorLogin()
        {
            InitializeComponent();
        }

        


        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Registerition register = new Registerition();

            register.Show();

            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }private void button1_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text;
            string password = txtPassword.Text;

            if (email == "" || password == "")
            {
                MessageBox.Show("Please enter email and password");
                return;
            }

            if (email == "menna@gmail.com" && password == "1234")
            {
                MessageBox.Show("Login Successful");

                DashboardInstructor instructor = new DashboardInstructor();

                instructor.Show();

                this.Hide();

            }
            else
            {
                MessageBox.Show("Invalid Email or Password");
            }
        }
    }
}
