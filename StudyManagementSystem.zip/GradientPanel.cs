﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

public class GradientPanel : Panel
{
    // اللون من فوق / البداية
    public Color ColorTop { get; set; } = Color.FromArgb(0, 102, 204);

    // اللون من تحت / النهاية
    public Color ColorBottom { get; set; } = Color.White;

    // اتجاه التدرج (زاوية)
    public float Angle { get; set; } = 90f;

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);

        LinearGradientBrush brush = new LinearGradientBrush(
            this.ClientRectangle,
            ColorTop,
            ColorBottom,
            Angle);

        e.Graphics.FillRectangle(brush, this.ClientRectangle);
    }
}